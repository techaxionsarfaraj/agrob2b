<template>
  <h1>Home</h1>
  <p>{{ message }}</p>
</template>
<script>
export default {
  name: 'Home',
  data() {
    return {
      message: 'Welcome to the Home Page!',
    }
  },
}
</script>
