<template>
  <Teleport to="#header">
    <Header />
  </Teleport>
  <div class="container">
    <li><router-link :to="{ name: 'Home' }" active-class="active">Home</router-link></li>
    <li>
      <router-link :to="{ name: 'About' }" active-class="active">About Us</router-link>
    </li>
    <router-view> </router-view>
  </div>
  <Teleport to="footer">
    <Footer />
  </Teleport>
</template>

<script>
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'

export default {
  name: 'App',
  components: {
    Header,
    Footer,
  },
}
</script>
